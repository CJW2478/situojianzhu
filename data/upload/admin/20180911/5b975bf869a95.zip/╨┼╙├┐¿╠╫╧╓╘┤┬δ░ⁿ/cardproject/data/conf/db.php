<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'thinkcard',
    'DB_USER' => 'root',
    'DB_PWD' => 'root',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'cmd_',
    //密钥
    "AUTHCODE" => '8AxjBQZtasBQE4dAnw',
    //cookies
    "COOKIE_PREFIX" => 'aiR9uU_',
);
